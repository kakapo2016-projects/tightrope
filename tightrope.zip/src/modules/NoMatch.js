import React from 'react'

export default React.createClass({
  render: function () {
    return (
      <div className='404-page'>
        <p>404</p>
        <p>I couldnt find those photos</p>
        <p>Did you fall off the tightrope?</p>
        <p>Go back <a href='/'>home</a> or <a href='/login'>sign up</a></p>
      </div>
    )
  }
})
