module.exports = [
  { user_id: 4, badge: 1, created_at: new Date(), updated_at: new Date() },
  { user_id: 4, badge: 2, created_at: new Date(), updated_at: new Date() },
  { user_id: 4, badge: 3, created_at: new Date(), updated_at: new Date() },
  { user_id: 4, badge: 4, created_at: new Date(), updated_at: new Date() },
  { user_id: 3, badge: 4, created_at: new Date(), updated_at: new Date() },
  { user_id: 1, badge: 2, created_at: new Date(), updated_at: new Date() },
  { user_id: 5, badge: 1, created_at: new Date(), updated_at: new Date() },
  { user_id: 4, badge: 5, created_at: new Date(), updated_at: new Date() }
]
