module.exports = [
  { photo_id: 1, user_id: 1, comment: 'admin comment', created_at: new Date(), updated_at: new Date() },
  { photo_id: 2, user_id: 1, comment: 'another admin comment', created_at: new Date(), updated_at: new Date() },
  { photo_id: 3, user_id: 1, comment: 'nice photo', created_at: new Date(), updated_at: new Date() },
  { photo_id: 4, user_id: 1, comment: 'wow', created_at: new Date(), updated_at: new Date() },
  { photo_id: 5, user_id: 1, comment: 'awesome', created_at: new Date(), updated_at: new Date() },
  { photo_id: 6, user_id: 3, comment: 'cool', created_at: new Date(), updated_at: new Date() },
  { photo_id: 1, user_id: 2, comment: 'nice', created_at: new Date(), updated_at: new Date() },
  { photo_id: 3, user_id: 1, comment: 'I like this', created_at: new Date(), updated_at: new Date() },
  { photo_id: 4, user_id: 1, comment: 'great!', created_at: new Date(), updated_at: new Date() },
]
