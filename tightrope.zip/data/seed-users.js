var moment = require('moment')
module.exports = [
  { username: 'jason', hashed_password: '$2a$10$rHq23YNSLeVBe.uMMJJbceShqTC5o7WSEUoFegymVI3I2Pb5qQl/K', email: 'jason@tightrope.io', profile_pic: 'http://res.cloudinary.com/dvzbt8kfq/image/upload/v1459213077/user_photos/giphy_pislrh.gif', credits: 100000000, active_streak: 10000, doa: moment().add(1, 'days'), created_at: moment(), updated_at: moment() },
  { username: 'admin', hashed_password: 'admin', email: 'admin@tightrope.io', profile_pic: 'http://fillmurray.com/800/800', credits: 0, active_streak: 0, doa: moment().add(1, 'days'), created_at: moment(), updated_at: moment() },
  { username: 'nick', hashed_password: 'nick', email: 'nick@tightrope.io', profile_pic: 'http://fillmurray.com/800/800', credits: 9, active_streak: 1, doa: moment().add(1, 'days'), created_at: moment(), updated_at: moment() },
  { username: 'test', hashed_password: '$2a$10$1wj8y9QOrlqZ0imw3x5fn.b.2MZ98PmRrhLR7K7QC3Frl6iqr06OG', email: 'test@test', profile_pic: 'http://fillmurray.com/800/800', credits: 9, active_streak: 32, doa: moment().add(1, 'days'), created_at: moment(), updated_at: moment() },
  { username: 'Nilu', hashed_password: '$2a$10$He22PTPaDQcmVTBgDddjHuCZb7GfKBA/oa6P5eHy4syEanlAsak8.', email: 'dooraven@gmail.com', profile_pic: 'http://res.cloudinary.com/dvzbt8kfq/image/upload/v1459215586/user_photos/tumblr_muwwmplfov1sglzlfo1_400_ebf0v3.gif', credits: 9, active_streak: 1, doa: moment().add(1, 'days'), created_at: moment(), updated_at: moment() }

]
