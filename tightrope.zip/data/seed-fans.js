module.exports = [
  { liker_id: 1, liked_id: 2, created_at: new Date(), updated_at: new Date() },
  { liker_id: 1, liked_id: 3, created_at: new Date(), updated_at: new Date() },
  { liker_id: 1, liked_id: 4, created_at: new Date(), updated_at: new Date() },
  { liker_id: 2, liked_id: 1, created_at: new Date(), updated_at: new Date() },
  { liker_id: 2, liked_id: 3, created_at: new Date(), updated_at: new Date() },
  { liker_id: 2, liked_id: 5, created_at: new Date(), updated_at: new Date() },
  { liker_id: 3, liked_id: 1, created_at: new Date(), updated_at: new Date() },
  { liker_id: 3, liked_id: 2, created_at: new Date(), updated_at: new Date() },
  { liker_id: 3, liked_id: 4, created_at: new Date(), updated_at: new Date() },
  { liker_id: 3, liked_id: 5, created_at: new Date(), updated_at: new Date() },
  { liker_id: 4, liked_id: 2, created_at: new Date(), updated_at: new Date() },
  { liker_id: 4, liked_id: 3, created_at: new Date(), updated_at: new Date() },
  { liker_id: 4, liked_id: 1, created_at: new Date(), updated_at: new Date() },
  { liker_id: 4, liked_id: 5, created_at: new Date(), updated_at: new Date() },
  { liker_id: 5, liked_id: 1, created_at: new Date(), updated_at: new Date() },
  { liker_id: 5, liked_id: 3, created_at: new Date(), updated_at: new Date() }
]
